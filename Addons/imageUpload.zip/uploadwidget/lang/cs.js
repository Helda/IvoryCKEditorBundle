/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uploadwidget', 'cs', {
	abort: 'Nahrávání zrušeno uživatelem.',
	doneOne: 'Soubor úspěšně nahrán.',
	doneMany: 'Úspěšně nahráno %1 souborů.',
	uploadOne: 'Nahrávání souboru ({percentage}%)...',
	uploadMany: 'Nahrávání souborů, {current} z {max} hotovo ({percentage}%)...'
} );
