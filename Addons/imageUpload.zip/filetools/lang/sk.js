/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'filetools', 'sk', {
	loadError: 'Počas čítania súboru nastala chyba.',
	networkError: 'Počas nahrávania súboru nastala chyba siete.',
	httpError404: 'Počas nahrávania súboru nastala HTTP chyba (404: Súbor nebol nájdený).',
	httpError403: 'Počas nahrávania súboru nastala HTTP chyba (403: Zakázaný).',
	httpError: 'Počas nahrávania súboru nastala HTTP chyba (error status: %1).',
	noUrlError: 'URL nahrávania nie je definovaný.',
	responseError: 'Nesprávna odpoveď servera.'
} );
